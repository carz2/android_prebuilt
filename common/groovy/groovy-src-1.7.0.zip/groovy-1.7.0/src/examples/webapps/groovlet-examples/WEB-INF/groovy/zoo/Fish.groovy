package zoo

abstract class Fish implements Animal {

  String saySomething(String something) {
    return "Blubb�: " + something + "..."
  }

}
