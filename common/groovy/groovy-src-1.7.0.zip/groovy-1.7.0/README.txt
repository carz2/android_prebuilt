$Id: README.txt 16387 2009-05-13 16:57:42Z paulk $

Building
========

To build you will need:

 * JDK 1.5+ (http://java.sun.com/j2se/)
 * Apache Ant 1.7+ (http://ant.apache.org)

For detailed instructions please see:

    http://groovy.codehaus.org/Building+Groovy+from+Source

To build everything, run tests and create a complete installation:

    ant install

To build without running tests:

    ant install -DskipTests=true

